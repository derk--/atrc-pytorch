
## PyTorch: A simple two layer fully connected network

Here we will go step by step through implmenting a very simple 2 layer fully connected network to label MNIST digits.

We start with a number of extra imports: pyplot lets us create plots, torch.nn is a torch library for implementing neural nets, and transforms is a torchvision package to help us work with image data, and datasets is a torchvision package granting us access to some built in test data. We will look at importing data in a later example.


```python
%matplotlib inline
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch.autograd import Variable
import torchvision.transforms as transforms
import torchvision.datasets as dsets
from timeit import default_timer as timer
```


```python
training_data = dsets.MNIST(root="./data", train = True, transform=transforms.ToTensor(), download = True)
```

    Downloading http://yann.lecun.com/exdb/mnist/train-images-idx3-ubyte.gz
    Downloading http://yann.lecun.com/exdb/mnist/train-labels-idx1-ubyte.gz
    Downloading http://yann.lecun.com/exdb/mnist/t10k-images-idx3-ubyte.gz
    Downloading http://yann.lecun.com/exdb/mnist/t10k-labels-idx1-ubyte.gz
    Processing...
    Done!


We should have a **validation set** of data as well, but the built in MNIST caller does not support a validation set, and we will just use the testing data set as the validation set for purpose of this tutorial.


```python
testing_data = dsets.MNIST(root="./data", train = False, transform=transforms.ToTensor(), download = True)
```




    10000




```python
## The mnist data comes in as a tuple. The first index is the pixel values packed in a pytorch Tensor, 
## the 2nd index is the class label.
# To show the image I have to make pytorch tensor a 
training_image_tensor = training_data[890][0]

# Note that the image is a 1x28x28 tensor: there is only one color channel; it is grayscale. 
print(training_image_tensor.shape)
plt.imshow(training_image_tensor[0])
```

    torch.Size([1, 28, 28])





    <matplotlib.image.AxesImage at 0x7f3f0d7b1450>




![png](output_5_2.png)



```python
class_label = training_data[890][1]
print(class_label)
```

    3


PyTorch comes with **built-in DataLoaders** that make it trivial to create minibatches and to enumerate over them. Always use these helpers!!

A DataLoader takes as input the desired minibatch size you would like (batch_size), and whether or not you would like the data to be shuffled before it is partitioned into minibatches. No shuffling means the exact same minibatches will be presented to your network every epoch. There is not a lot of guidance as to whether shuffling is good or bad, but intuition says shuffling should help with generalizability a bit.

The DataLoader function returns an *iterator* over your datasets with shuffling and batchsize specified.


```python
batch_size = 32
train_loader = torch.utils.data.DataLoader(dataset=training_data, batch_size=batch_size, shuffle=True)
test_loader = torch.utils.data.DataLoader(dataset=testing_data, batch_size=len(testing_data), shuffle=False)

len(train_loader)
```




    1875



## Setting up a deep net
### 1. Specify and instantiate the network.

Here we go. A DNN is specified as a class that inherets from nn.Module. They all have the same structure:
<ol>
    <li> a call to the constructor of nn.Module (super)
    <li> specification of a number of network layers. It is common practice to wrap the way the nodes are wired and the activation function (and any other processing, like doing batch norm) inside of an nn.Sequential object. nn.Sequential is just a convinent wrapper of a number of nn.function calls. 
    <li> Definition of a **forward** function. This function must be specified. This function describes the way that data will pass through your deep net. Here, we see that the input will bass through fc1, then fc2, and we return thr output of fc2. 
        </ol>
        
A few things to note: 
<ol> 
    <li> We do not need to tell the deep net what the size of the minibatch we will present to it is.
    <li> nn.Linear specifies a linear combination of inputs into a layer. The linear combination is the $\sum_i w_i x_i$ we are used to seeing, where the summation is over **every node in the previous layer**. So nn.Linear specifies a fully-connected connectivity in this layer. 
<li> We simply output the ReLU activation values of fc2 -- we do not normalize these values so they sum to 1. We may want to do a normalization here if we want the network to output a score for the likelihood the input is of each class that looks like a probability. We could do so by specifiying a **softmax** layer. But this is equivalent to just predicting the class corresponding to the fc2 output that is maximum.
    </ol>
    

**The PyTorch docs are a great place to see what types of layers and activations are implemented**. Of course, nothing is stoping you from implementing your own layer or activation function and then call those functions inside of the deep net specification.


```python
class DeepNet(nn.Module):
    def __init__(self, input_size, hidden_size, num_classes):
        super(DeepNet, self).__init__()
        
        self.fc1 = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU()
        )
        self.fc2 = nn.Sequential(
            nn.Linear(hidden_size,hidden_size),
            nn.ReLU()
        )
        self.output = nn.Sequential(
            nn.Linear(hidden_size, num_classes),
            nn.ReLU()
        )
    
    def forward(self, x):
        out = self.fc1(x)
        out = self.fc2(out)
        out = self.output(out)
        return out
```


```python
input_size = 28*28 ## Note that an MNIST image is 28*28 pixels.
num_classes = 10
hidden_size = 10
the_net = DeepNet(input_size, hidden_size, num_classes)
print(the_net)

## the parameters() function of an nn.Module object returns an iterator over 
## all of the network parameters (e.g. weights.) PyTorch initializes all weights in linear and
## conv layers as: 
## stdv = 1. / math.sqrt(number_of_layer_inputs)
## self.weight.data.uniform_(-stdv, stdv)
## So with uniformly distributed weights within -stdv, stdv.

## If you want to see what the parameters are, iterate over parameters() or make it a list:
params = list(the_net.parameters())
## We print the parameters of the network in order of weights, then biases, for each layer that has weights and 
## biases, in sequential order of operation in the forward pass. 
print(params)

## If you want to specify your own weight initiaization routine, you can do it simply!
## It is possible to . through the structure of the_net. any Sequential layers are lists, so fc2[0] is the 
## nn.Linear in fc2. fc2[1] is the ReLU activation.
## Remember that _ suffix means in place updating.
the_net.fc2[0].weight.data.normal_(10,0.01)
the_net.fc2[0].bias.data.normal_(50,0.01)
print(params)

## anyway, these weights are horrible. Let's reinitialize the network. :) 
the_net = DeepNet(input_size, hidden_size, num_classes)
print(list(the_net.parameters()))
```

    DeepNet(
      (fc1): Sequential(
        (0): Linear(in_features=784, out_features=10)
        (1): ReLU()
      )
      (fc2): Sequential(
        (0): Linear(in_features=10, out_features=10)
        (1): ReLU()
      )
      (output): Sequential(
        (0): Linear(in_features=10, out_features=10)
        (1): ReLU()
      )
    )
    [Parameter containing:
    1.00000e-02 *
     2.5436 -2.1927 -3.3524  ...   3.0668  1.8614  3.2343
     1.4068 -1.3977 -2.5394  ...  -0.7758 -1.9729  2.4468
    -3.2340  0.5947 -3.3617  ...  -3.5204  1.7534 -2.2791
              ...             ⋱             ...          
     0.1256  2.1510 -2.2834  ...   2.0234 -1.0439 -3.3102
    -2.8738  2.7599  2.5549  ...  -3.0116 -3.1609 -0.8644
    -0.6734  1.5868  3.0672  ...  -1.1066 -2.4457  3.2477
    [torch.FloatTensor of size 10x784]
    , Parameter containing:
    1.00000e-02 *
      3.4262
     -2.0045
      0.7448
      2.1001
     -0.3384
     -2.2033
      2.4331
      3.0071
      3.4535
     -1.3281
    [torch.FloatTensor of size 10]
    , Parameter containing:
     0.1248 -0.3092  0.1243 -0.1529 -0.0489  0.2485 -0.2061 -0.0625 -0.0925 -0.1836
     0.1565 -0.2618  0.2047 -0.2585  0.2483  0.0656  0.1975  0.2855  0.1935  0.1130
    -0.3114  0.2089 -0.2109 -0.2287 -0.3162 -0.0833  0.2638 -0.1494  0.1019 -0.2025
     0.2662  0.1302 -0.1666 -0.1696  0.0224  0.1577  0.2719  0.0282 -0.1737  0.0523
     0.2110  0.1336  0.2392  0.1208 -0.3100  0.1550  0.1696 -0.2218  0.0313 -0.0253
    -0.0660  0.0938 -0.1160 -0.0767  0.0857 -0.2709 -0.0667  0.0889 -0.2848 -0.2883
     0.1117  0.2866  0.2904 -0.3020 -0.1503  0.1833 -0.1875  0.2319 -0.1154 -0.1431
     0.2684  0.1418 -0.2807  0.1213  0.3115 -0.1391  0.2284 -0.0425 -0.1391  0.0232
    -0.2282  0.0132 -0.2468  0.2521 -0.1795 -0.0424 -0.0556  0.1260  0.3044  0.0721
    -0.0943 -0.2553  0.1955 -0.1125  0.2486  0.0297 -0.1059  0.0291  0.2666 -0.2971
    [torch.FloatTensor of size 10x10]
    , Parameter containing:
    -0.0510
    -0.2370
     0.1620
     0.0735
     0.0409
    -0.2272
    -0.2771
    -0.2239
    -0.2650
    -0.1283
    [torch.FloatTensor of size 10]
    , Parameter containing:
    -0.3098  0.0528 -0.2161 -0.1235  0.1357  0.1983 -0.1684 -0.1048  0.2910  0.2453
     0.1971 -0.2044  0.2669 -0.3131 -0.2939 -0.2003  0.1409 -0.1482  0.1366  0.1086
     0.1238  0.0882  0.1126  0.0775  0.1893 -0.1466 -0.0006  0.0489 -0.2574  0.1065
     0.1761 -0.1618 -0.1239  0.1487 -0.1771  0.1330 -0.2807  0.0497  0.1227  0.2485
     0.1292  0.3115 -0.0424 -0.2841  0.0460 -0.0260 -0.2770 -0.2284  0.2982 -0.1160
     0.1198 -0.3064  0.1104 -0.0549 -0.1064 -0.0214  0.1088  0.1654 -0.1460 -0.0111
     0.0872  0.2049 -0.0353 -0.0393  0.2356 -0.0135  0.2160  0.0137  0.1392 -0.0915
    -0.1973  0.1910  0.1073 -0.2114  0.1294 -0.0394 -0.0613  0.0664  0.2545  0.0821
     0.0812 -0.3069 -0.1981 -0.0541  0.0743 -0.1999 -0.0555 -0.2673  0.0153  0.1432
     0.0244 -0.2518  0.0122  0.2364  0.2464 -0.2766 -0.0653  0.2933 -0.0558  0.0722
    [torch.FloatTensor of size 10x10]
    , Parameter containing:
     0.2450
     0.1077
    -0.0482
     0.2755
    -0.0746
    -0.0784
    -0.0382
    -0.0976
     0.1022
     0.0547
    [torch.FloatTensor of size 10]
    ]
    [Parameter containing:
    1.00000e-02 *
     2.5436 -2.1927 -3.3524  ...   3.0668  1.8614  3.2343
     1.4068 -1.3977 -2.5394  ...  -0.7758 -1.9729  2.4468
    -3.2340  0.5947 -3.3617  ...  -3.5204  1.7534 -2.2791
              ...             ⋱             ...          
     0.1256  2.1510 -2.2834  ...   2.0234 -1.0439 -3.3102
    -2.8738  2.7599  2.5549  ...  -3.0116 -3.1609 -0.8644
    -0.6734  1.5868  3.0672  ...  -1.1066 -2.4457  3.2477
    [torch.FloatTensor of size 10x784]
    , Parameter containing:
    1.00000e-02 *
      3.4262
     -2.0045
      0.7448
      2.1001
     -0.3384
     -2.2033
      2.4331
      3.0071
      3.4535
     -1.3281
    [torch.FloatTensor of size 10]
    , Parameter containing:
    
    Columns 0 to 7 
     10.0177   9.9859   9.9952   9.9986   9.9984   9.9952  10.0007  10.0144
     10.0093   9.9888   9.9861   9.9974   9.9964   9.9848  10.0168   9.9930
     10.0008  10.0026  10.0060  10.0119  10.0049   9.9875  10.0130  10.0182
     10.0040   9.9879  10.0225  10.0017   9.9973  10.0063  10.0134   9.9993
      9.9924  10.0068   9.9972   9.9852  10.0015  10.0049   9.9842  10.0162
      9.9985  10.0049  10.0134  10.0022   9.9930  10.0053   9.9859  10.0104
      9.9925  10.0180  10.0034   9.9995  10.0031  10.0022  10.0084  10.0097
      9.9964   9.9921   9.9927  10.0105  10.0151  10.0194  10.0124   9.9885
      9.9962   9.9986  10.0067  10.0234  10.0122  10.0011   9.9988  10.0108
      9.9958   9.9828  10.0045  10.0065   9.9946   9.9997   9.9880  10.0076
    
    Columns 8 to 9 
      9.9953  10.0086
      9.9851   9.9941
      9.9922  10.0002
      9.9998   9.9961
     10.0068   9.9918
     10.0274  10.0212
     10.0019   9.9966
     10.0012   9.9948
      9.9885   9.9964
     10.0130   9.9978
    [torch.FloatTensor of size 10x10]
    , Parameter containing:
     50.0038
     49.9996
     49.9895
     49.9964
     49.9927
     49.9999
     50.0074
     50.0017
     49.9951
     50.0015
    [torch.FloatTensor of size 10]
    , Parameter containing:
    -0.3098  0.0528 -0.2161 -0.1235  0.1357  0.1983 -0.1684 -0.1048  0.2910  0.2453
     0.1971 -0.2044  0.2669 -0.3131 -0.2939 -0.2003  0.1409 -0.1482  0.1366  0.1086
     0.1238  0.0882  0.1126  0.0775  0.1893 -0.1466 -0.0006  0.0489 -0.2574  0.1065
     0.1761 -0.1618 -0.1239  0.1487 -0.1771  0.1330 -0.2807  0.0497  0.1227  0.2485
     0.1292  0.3115 -0.0424 -0.2841  0.0460 -0.0260 -0.2770 -0.2284  0.2982 -0.1160
     0.1198 -0.3064  0.1104 -0.0549 -0.1064 -0.0214  0.1088  0.1654 -0.1460 -0.0111
     0.0872  0.2049 -0.0353 -0.0393  0.2356 -0.0135  0.2160  0.0137  0.1392 -0.0915
    -0.1973  0.1910  0.1073 -0.2114  0.1294 -0.0394 -0.0613  0.0664  0.2545  0.0821
     0.0812 -0.3069 -0.1981 -0.0541  0.0743 -0.1999 -0.0555 -0.2673  0.0153  0.1432
     0.0244 -0.2518  0.0122  0.2364  0.2464 -0.2766 -0.0653  0.2933 -0.0558  0.0722
    [torch.FloatTensor of size 10x10]
    , Parameter containing:
     0.2450
     0.1077
    -0.0482
     0.2755
    -0.0746
    -0.0784
    -0.0382
    -0.0976
     0.1022
     0.0547
    [torch.FloatTensor of size 10]
    ]
    [Parameter containing:
    -6.9333e-03 -3.8987e-03  4.3111e-03  ...   1.0071e-02 -3.2693e-03 -2.1465e-02
    -1.3219e-02  1.3584e-02 -3.4353e-02  ...   4.3695e-03  2.1827e-03  1.8436e-02
    -3.2045e-02  1.5981e-02 -3.1610e-02  ...  -1.8946e-02  1.5791e-02  2.6620e-02
                    ...                   ⋱                   ...                
     1.2730e-02 -2.0597e-02  4.5482e-03  ...   3.2265e-02 -1.0771e-02 -7.2060e-03
     1.3142e-02  1.4454e-02 -1.6190e-02  ...   1.0851e-02  1.3865e-03 -1.1458e-02
    -2.4839e-02  2.5785e-02 -1.1370e-02  ...   2.3801e-02 -3.0834e-02  3.5177e-02
    [torch.FloatTensor of size 10x784]
    , Parameter containing:
    1.00000e-02 *
      1.4460
      3.1542
      2.6421
     -1.9068
      2.7696
      0.6319
      3.0326
     -0.5811
      0.8624
      3.2418
    [torch.FloatTensor of size 10]
    , Parameter containing:
     0.2101  0.1695  0.2275 -0.0253  0.1524  0.0026  0.0646  0.1381 -0.2761 -0.1742
    -0.0330  0.1651 -0.1331  0.1331  0.2072 -0.0381 -0.0499  0.0130  0.2147  0.1801
     0.2222  0.2846  0.2039  0.1831 -0.1103 -0.1720  0.2538 -0.1687 -0.1368 -0.2709
     0.0102 -0.1999  0.1912 -0.2216  0.0117  0.0082  0.0577 -0.2074 -0.3076  0.1835
    -0.0078 -0.1391  0.2952  0.0229 -0.2497  0.2612 -0.1164  0.2577  0.0695 -0.2388
     0.2211  0.0881 -0.0947 -0.0151 -0.0718 -0.1679 -0.1770 -0.0618 -0.0074  0.0174
     0.0256  0.0893 -0.2919 -0.2228  0.2266  0.3125  0.1938  0.2491 -0.1764 -0.0773
     0.2031  0.0687 -0.1020 -0.0792  0.2451 -0.0276  0.3141  0.0593  0.0980 -0.1899
    -0.2213  0.1857  0.0256  0.2974 -0.1914 -0.1599  0.0821 -0.3004 -0.2510  0.1402
     0.1570 -0.0195 -0.2037  0.2726  0.0555  0.1830 -0.2468  0.2951  0.2059 -0.1868
    [torch.FloatTensor of size 10x10]
    , Parameter containing:
    -0.0582
    -0.1969
    -0.1988
    -0.1186
     0.0907
     0.0589
    -0.1226
    -0.2509
    -0.2934
     0.2763
    [torch.FloatTensor of size 10]
    , Parameter containing:
     0.2201 -0.3040  0.1057  0.1714 -0.1173 -0.2448 -0.1392 -0.2948 -0.0701 -0.2227
    -0.0376  0.1586 -0.2344  0.1002 -0.1869 -0.0661  0.2398  0.0689 -0.2153 -0.2089
     0.0771  0.1994  0.1201 -0.2627 -0.2660 -0.1412 -0.1539  0.2172 -0.0027  0.2541
    -0.2407 -0.2368  0.0794 -0.1576 -0.2460 -0.1468  0.2780 -0.0615 -0.1110 -0.1358
    -0.0693 -0.2514  0.1497 -0.0169 -0.0520 -0.0684  0.2542  0.2733 -0.0310  0.1410
    -0.0824  0.0704  0.1974 -0.1649  0.1729  0.2121  0.2073 -0.0821 -0.0142 -0.0331
     0.0826 -0.0796  0.1292 -0.1252  0.0061  0.0662 -0.2772 -0.2863  0.0007 -0.0473
     0.1059  0.2644  0.3028  0.0770 -0.1034 -0.1977  0.0354 -0.0113 -0.2054  0.0141
     0.1053 -0.1466 -0.1095  0.2880  0.2680 -0.2269  0.1650  0.2203  0.1314 -0.2699
    -0.2245  0.1325  0.2651  0.1333  0.2445  0.0482 -0.2117 -0.2592  0.1591  0.2451
    [torch.FloatTensor of size 10x10]
    , Parameter containing:
     0.2438
    -0.2046
     0.0915
     0.0317
     0.3120
     0.1940
     0.0717
    -0.1955
     0.0705
    -0.0977
    [torch.FloatTensor of size 10]
    ]


### 2. Define your loss function.

Since we are tackling a classification problem we want to use cross entropy loss. For those who know cross entropy (or have heard of **entropy** before) would know that the loss must operate on a probability distribution. And indeed it does: this loss expects the probability the network thinks the input is of each class. In PyTorch, **this normalization (e.g. passing the output of fc2 through a *softmax layer*) is done automatically by the loss function**. I (Derek) don't really like this, its a bit of a gotcha! Now you know!


```python
loss_function = nn.CrossEntropyLoss()
```

### 3. Define your optimizer.

When in doubt, start with ADAM since it adapts its learning rate over time. Start with a low learning rate.


```python
learning_rate = 0.01
optimizer = torch.optim.Adam(the_net.parameters(), lr=learning_rate)
```

### 4. Begin training.
We will train in a loop that iterates over the minibatches yielded from train_loader, for a fixed number of epochs. Here is what's going on: 
<ol>
    <li> We are specifying a loop for 10 epochs. In the loop we wrap the train_loader in an enumerator. The enumerator will yield an enumeration count and a tuple (minibatch_of_images, minibatch_of_labels). 
    <li> The minibatch_of_images is a 4D tensor with dimensions (size_of_minibatch, depth, width, height). The network expects as input a vector of size 28*28 so we need to reshape the tensor accordingly. We will reshape it to a matrix of 32 rows, 28*28 columns. Note that we can pass -1 as the first parameter of view, this is like saying "I don't know how many rows I'll need, just make as many as needed to the column count I specify (28*28) is satisfied.


```python
num_epochs = 3
for epoch in range(num_epochs):
    for _ , (minibatch_of_images, minibatch_of_labels) in enumerate(train_loader):
        print minibatch_of_images.shape
        print minibatch_of_images.view(32, 28*28).shape
        break
```

    torch.Size([32, 1, 28, 28])
    torch.Size([32, 784])


<ol>
    <li> We build a computation graph here to setup backprop! So wrap the labels and the batch in a Variable.
    <li> Tell the optimizer to zero out any gradient stored in the Variables of the parameters of the_net. Indeed, the optimizer knows of the_net's parameters as we passed them in as a required parameter of the optimizer above. **Zero the gradient out after every minibatch!**
     <li> Okay, run the_batch through the_net. This is the **forward pass**. Note that outputs will be a Variable.
     <li> Compute the loss, how much error the network had on the_batch.
     <li> Now backprop! loss is a real number value, so that will be the gradient signal. Observe. loss is a functino of the outputs, which is a function of the_net, which is a function of the_batch. So the computation chain is all setup! 
      <li> Tell the optimizer to update the weights by calling step(). Step tells the optimizer to use the gradients stored at each network parameter (computed by calling backward() on loss) to compute and apply a weight update.
      <li> Give some console output to see how we are doing every few minibatches.


```python
num_epochs = 10
for epoch in range(num_epochs):
    start = timer()
    for batch_num , (minibatch_of_images, minibatch_of_labels) in enumerate(train_loader):
    
        the_batch = Variable(minibatch_of_images.view(32, 28*28))
        labels = Variable(minibatch_of_labels)
        
        optimizer.zero_grad()
        
        output = the_net(the_batch)
        
        loss = loss_function(output, labels)
        
        loss.backward()
        
        optimizer.step()
        
        _, predicted = torch.max(output.data, 1)
        batch_accuracy = 1.0*(predicted == labels.data).sum()/labels.size(0)
        # we want to check the accuracy with test dataset every 600 iterations.
        if batch_num % 600 == 0:

            # calculate accuracy
            correct = 0
            
            # iterate through test dataset
            for _, (images, labels) in enumerate(test_loader):
                images = Variable(images.view(-1, 28*28))
                
                outputs = the_net(images)
                # get predictions from the maximum value
                _, predicted = torch.max(outputs.data, 1)
                
                correct += (predicted == labels).sum()
            
            accuracy =  1.0*correct / labels.size(0)
            
            print("At epoch %i, minibatch %i. Loss: %.4f. Accuracy on the batch: %.4f. Accuracy on the test data: %.4f"\
                  % (epoch, batch_num, loss.data[0], batch_accuracy, accuracy))
    end = timer()
    print("Epoch %i finished! It took: %.4f seconds" % (epoch, end - start))
```

    At epoch 0, minibatch 0. Loss: 0.6616. Accuracy on the batch: 0.7500. Accuracy on the test data: 0.7398
    At epoch 0, minibatch 600. Loss: 0.6977. Accuracy on the batch: 0.7812. Accuracy on the test data: 0.7418
    At epoch 0, minibatch 1200. Loss: 0.9206. Accuracy on the batch: 0.6250. Accuracy on the test data: 0.7447
    At epoch 0, minibatch 1800. Loss: 0.6930. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7457
    Epoch 0 finished! It took: 6.5924 seconds
    At epoch 1, minibatch 0. Loss: 0.6969. Accuracy on the batch: 0.7500. Accuracy on the test data: 0.7444
    At epoch 1, minibatch 600. Loss: 0.6678. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7465
    At epoch 1, minibatch 1200. Loss: 0.6927. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7489
    At epoch 1, minibatch 1800. Loss: 0.6514. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7482
    Epoch 1 finished! It took: 6.6015 seconds
    At epoch 2, minibatch 0. Loss: 0.8018. Accuracy on the batch: 0.6875. Accuracy on the test data: 0.7358
    At epoch 2, minibatch 600. Loss: 0.6873. Accuracy on the batch: 0.7812. Accuracy on the test data: 0.7431
    At epoch 2, minibatch 1200. Loss: 0.7893. Accuracy on the batch: 0.6562. Accuracy on the test data: 0.7457
    At epoch 2, minibatch 1800. Loss: 0.8170. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7493
    Epoch 2 finished! It took: 6.6246 seconds
    At epoch 3, minibatch 0. Loss: 0.7546. Accuracy on the batch: 0.7500. Accuracy on the test data: 0.7504
    At epoch 3, minibatch 600. Loss: 0.6735. Accuracy on the batch: 0.7812. Accuracy on the test data: 0.7464
    At epoch 3, minibatch 1200. Loss: 0.5969. Accuracy on the batch: 0.8438. Accuracy on the test data: 0.7472
    At epoch 3, minibatch 1800. Loss: 1.0600. Accuracy on the batch: 0.6875. Accuracy on the test data: 0.7467
    Epoch 3 finished! It took: 6.5411 seconds
    At epoch 4, minibatch 0. Loss: 0.9054. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7439
    At epoch 4, minibatch 600. Loss: 0.5935. Accuracy on the batch: 0.7812. Accuracy on the test data: 0.7465
    At epoch 4, minibatch 1200. Loss: 0.5356. Accuracy on the batch: 0.7812. Accuracy on the test data: 0.7482
    At epoch 4, minibatch 1800. Loss: 0.6344. Accuracy on the batch: 0.7500. Accuracy on the test data: 0.7354
    Epoch 4 finished! It took: 6.5662 seconds
    At epoch 5, minibatch 0. Loss: 0.5494. Accuracy on the batch: 0.7812. Accuracy on the test data: 0.7475
    At epoch 5, minibatch 600. Loss: 0.8096. Accuracy on the batch: 0.6250. Accuracy on the test data: 0.7452
    At epoch 5, minibatch 1200. Loss: 0.8237. Accuracy on the batch: 0.6875. Accuracy on the test data: 0.7433
    At epoch 5, minibatch 1800. Loss: 0.4874. Accuracy on the batch: 0.8125. Accuracy on the test data: 0.7468
    Epoch 5 finished! It took: 6.5308 seconds
    At epoch 6, minibatch 0. Loss: 0.7111. Accuracy on the batch: 0.7500. Accuracy on the test data: 0.7452
    At epoch 6, minibatch 600. Loss: 0.9170. Accuracy on the batch: 0.6562. Accuracy on the test data: 0.7306
    At epoch 6, minibatch 1200. Loss: 1.0429. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7479
    At epoch 6, minibatch 1800. Loss: 0.7110. Accuracy on the batch: 0.7500. Accuracy on the test data: 0.7454
    Epoch 6 finished! It took: 6.4622 seconds
    At epoch 7, minibatch 0. Loss: 0.7477. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7492
    At epoch 7, minibatch 600. Loss: 0.6140. Accuracy on the batch: 0.7500. Accuracy on the test data: 0.7436
    At epoch 7, minibatch 1200. Loss: 0.2559. Accuracy on the batch: 0.9062. Accuracy on the test data: 0.7449
    At epoch 7, minibatch 1800. Loss: 0.9022. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7378
    Epoch 7 finished! It took: 6.4998 seconds
    At epoch 8, minibatch 0. Loss: 0.9104. Accuracy on the batch: 0.6562. Accuracy on the test data: 0.7401
    At epoch 8, minibatch 600. Loss: 0.8011. Accuracy on the batch: 0.7188. Accuracy on the test data: 0.7414
    At epoch 8, minibatch 1200. Loss: 0.5399. Accuracy on the batch: 0.8125. Accuracy on the test data: 0.7441
    At epoch 8, minibatch 1800. Loss: 0.7545. Accuracy on the batch: 0.6875. Accuracy on the test data: 0.7443
    Epoch 8 finished! It took: 6.3648 seconds
    At epoch 9, minibatch 0. Loss: 0.4597. Accuracy on the batch: 0.8125. Accuracy on the test data: 0.7450
    At epoch 9, minibatch 600. Loss: 1.0978. Accuracy on the batch: 0.6562. Accuracy on the test data: 0.7460
    At epoch 9, minibatch 1200. Loss: 0.3810. Accuracy on the batch: 0.8438. Accuracy on the test data: 0.7397
    At epoch 9, minibatch 1800. Loss: 0.6757. Accuracy on the batch: 0.7812. Accuracy on the test data: 0.7437
    Epoch 9 finished! It took: 6.5416 seconds



```python
torch.cuda.is_available()
```




    True



Author: Derek Doran, Dept. of CSE, Wright State University, for ATRC Summer 2018. 

Homepage: https://derk--.github.io/
